const fs = require('fs');
const path = require('path');

const directory = './Logs';


function removeFiles(directory) {
  fs.readdirSync(directory).forEach(file => {
    const filePath = path.join(directory, file);
    if (fs.statSync(filePath).isDirectory()) {
      removeFiles(filePath); 
    } else {
      console.log('delete file...',file);
      fs.unlinkSync(filePath); 
    }
  });
}


function removeDirectory(directory) {
  if (fs.existsSync(directory)) {
    fs.rmdirSync(directory);
  }
}


if (fs.existsSync(directory) && fs.lstatSync(directory).isDirectory()) {

  removeFiles(directory);


  removeDirectory(directory);
} else {
  console.log('Log directory does not exist.');
}