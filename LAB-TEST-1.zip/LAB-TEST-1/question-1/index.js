function lowerCaseWords(arr) {
    return new Promise(function(resolve, reject){
        if(!Array.isArray(arr)){
            reject('input is not an array')
            return;
        }

        var arrayWords = arr.filter(item => typeof item === "string");
        var lowerCase = arrayWords.map(word => word.toLowerCase());

        if (lowerCase.length === 0) {
        reject("No valid words found in the input array.");
        } else {
        resolve(lowerCase);
        }
    })
}

var array = ['PIZZA', 10, true, 25, false, 'Wings'];
lowerCaseWords(array)
  .then(result => {
    console.log("Lower cased words:", result);
  })
  .catch(error => {
    console.error("Error:", error);
  });