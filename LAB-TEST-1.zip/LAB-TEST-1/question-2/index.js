function resolvedPromise() {
    return new Promise(function(resolve) {
        setTimeout(() => {
            resolve('message: delayedSuccess');
        }, 500)
    });
}

function rejectedPromise() {
    return new Promise(function(reject) {
        setTimeout(() => {
            reject('error: delayedException');
        }, 500)
    });
}

resolvedPromise()
  .then(result => {
    console.log(result);
  })
  .catch(error => {
    console.error(error);
  });


rejectedPromise()
  .then(result => {
    console.log(result);
  })
  .catch(error => {
    console.error(error);
  });